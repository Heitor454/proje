<?php
require_once('conexao.php');

if( isset($_POST['txtAdministrador']) 
&& isset($_POST['txtCpf']) 
&& isset($_POST['txtEmail']) 
&& isset($_POST['txtSenha']) 
){  
    $administrador = $_POST['txtAdministrador'];
    $telefone = $_POST['txtTelefone'];
    $email = $_POST['txtEmail'];
    $cpf = $_POST['txtCpf'];
 

    $control = $conecta->prepare("INSERT INTO tb_administrador(administrador, cpf, email, senha) 
    VALUES (
    :ADMINISTRADOR,
    :CPF,
    :EMAIL,
    :SENHA,
)");


    $control->bindParam("ADMINISTRADOR", $administrador);
    $control->bindParam("CPF", $cpf);    
    $control->bindParam("EMAIL", $email); 
    $control->bindParam("SENHA", $senha); 
    $control->execute();

    header('Location: http://localhost/Projeto/visualizaçao/home.php');
}
