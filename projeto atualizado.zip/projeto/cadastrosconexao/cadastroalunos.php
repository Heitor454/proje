<?php
require_once('conexao.php');

if( isset($_POST['txtNome']) 
&& isset($_POST['txtCPF']) 
&& isset($_POST['txtTel']) 
&& isset($_POST['txtMail']) 
&& isset($_POST['txtData_Nascimento'])
&& isset($_POST['txtCel'])
&& isset($_POST['txtGenero'])
&& isset($_POST['txtForma_Ingresso'])
&& isset($_POST['txtCurso'])
&& isset($_POST['txtCurso'])
&& isset($_POST['txtData_Prova'])
&& isset($_POST['txtHorario_prova'])
&& isset($_POST['txtLocal_prova'])
&& isset($_POST['txtCpf'])
&& isset($_POST['txtRg'])
&& isset($_POST['txtCep'])
&& isset($_POST['txtEndereco'])
&& isset($_POST['txtNum'])
&& isset($_POST['txtComplemento'])
&& isset($_POST['txtBairro'])
&& isset($_POST['txtCidade'])
&& isset($_POST['txtNome_Social'])
&& isset($_POST['txtNecessidade_Especial'])){  

    $nome = $_POST['txtNome'];
    $telefone = $_POST['txtTel'];
    $email = $_POST['txtMail'];
    $data_nascimento = $_POST['txtData_Nascimento'];
    $celular = $_POST['txtCel'];
    $genero = $_POST['txtGenero'];
    $forma_ingresso = $_POST['txtForma_Ingresso'];
    $curso = $_POST['txtCurso'];
    $habilitacao = $_POST['txtCurso'];
    $desconto = $_POST['txtDesconto'];
    $data_prova = $_POST['txtData_Prova'];
    $horario_prova = $_POST['txtHorario_prova'];
    $local_prova = $_POST['txtLocal_prova'];
    $cpf = $_POST['txtCpf'];
    $rg = $_POST['txtRg'];
    $cep = $_POST['txtCep'];
    $endereco = $_POST['txtEndereco'];
    $num = $_POST['txtNum'];
    $complemento = $_POST['txtComplemento'];
    $bairro = $_POST['txtBairro'];
    $cidade = $_POST['txtCidade'];
    $nome_social = $_POST['txtNome_Social'];
    $necessidade_especial = $_POST['txtNecessidade_Especial'];

    $control = $conecta->prepare("INSERT INTO tb_alunos(nome,tuma,cadastrodealunos,data_nascimento,celular,genero,forma_ingresso,curso,habilitacao,desconto,
    data_prova,horario_prova,local_prova,cpf,rg,endereco,num,complemento,bairro,cidade,nome_social,necessidade_especial) 
    VALUES (:NOME, 
    :TURMA,
    :CADASTRO_DE_ALUNOS,
    :CELULAR,
    :GENERO,
    :FORMA_INGRESSO,
    :CURSO,
    :HABILITACAO,
    :DESCONTO,
    :DATA_PROVA,
    :HORARIO_PROVA,
    :LOCAL_PROVA,
    :CPF,
    :RG,
    :CEP,
    :ENDERECO,
    :NUM,
    :COMPLEMENTO,
    :BAIRRO,
    :CIDADE,
    :NOME_SOCIAL,
    :NECESSEIDADE_ESPECIAL,)");

    $control->bindParam("NOME", $name);
    $control->bindParam("TURMA", $telefone);
    $control->bindParam("CADASTRO_DE_ALUNOS", $cadastrodealunos);
    $control->bindParam("DATA_NASCIMENTO",$data_nascimento);
    $control->bindParam("CELULAR",$celular);
    $control->bindParam("GENERO",$genero);
    $control->bindParam("FORMA_INGRESSO",$forma_ingresso);
    $control->bindParam("CURSO",$curso);
    $control->bindParam("HABILITACAO",$habilitacao);
    $control->bindParam("DESCONTO",$desconto);
    $control->bindParam("DATA_PROVA",$data_prova);
    $control->bindParam("HORARIO_PROVA",$horario_prova);
    $control->bindParam("LOCAL_PROVA",$local_prova);
    $control->bindParam("CPF",$cpf);
    $control->bindParam("RG",$rg);
    $control->bindParam("CEP",$cep);
    $control->bindParam("ENDERECO",$endereco);
    $control->bindParam("NUM",$num);
    $control->bindParam("COMPLEMENTO",$complemento);
    $control->bindParam("BAIRRO",$bairro);
    $control->bindParam("CIDADE",$cidade);
    $control->bindParam("NOME_SOCIAL",$nome_social);
    $control->bindParam("NECESSEIDADE_ESPECIAL",$necessidade_especial);
    $control->execute();

    header('Location: http://localhost/Projeto/visualizacao/home.php');
}
