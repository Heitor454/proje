<?php
// conexão com o banco de dados;

require_once('conexao.php');

if(isset($_POST['txtNome'])
&& isset($_POST['txtData_Nascimento'])
&& isset($_POST['txtEndereco']) 
&& isset($_POST['txtCep'])
&& isset($_POST['txtCidade'])
&& isset($_POST['txtTelefone'])
&& isset($_POST['txtCelular'])
&& isset($_POST['txtEmail'])
&& isset($_POST['txtInteresse'])
&& isset($_POST['txtTurno'])
&& isset($_POST['txtSemana'])
){

 //captura os dados vindos do input do formulário;
$nome = $_POST['txtNome'];
$data_nascimento = $_POST['txtData_Nascimento'];
$endereco = $_POST['txtEndereco'];
$cep = $_POST['txtCep'];
$cidade = $_POST['txtCidade'];
$telefone = $_POST['txtTelefone'];
$celular = $_POST['txtCelular'];
$email = $_POST['txtEmail'];
$interesse = $_POST['txtInteresse'];
$turno = $_POST['txtTurno'];
$semana = $_POST['txtSemana'];


//insere os dados no banco de dados;

$control = $conecta->prepare("INSERT INTO tb_cursos(nome,data_nascimento,endereco,cep,cidade,telefone,celular,email,interesse,turno,semana) 
VALUES (:NOME, :DATA_NASCIMENTO, :ENDERECO, :CEP, :CIDADE, :TELEFONE, :CELULAR, :EMAIL, :INTERESSE, :TURNO, :SEMANA, )");
$control->bindParam("NOME", $Nome);
$control->bindParam("DATA_NASCIMENTO", $data_nascimento);
$control->bindParam("ENDERECO", $endereco);
$control->bindParam("CEP", $cep);
$control->bindParam("CIDADE", $cidade);
$control->bindParam("TELEFONE", $telefone);
$control->bindParam("CELULAR", $celular);
$control->bindParam("EMAIL", $email);
$control->bindParam("INTERESSE", $interesse);
$control->bindParam("TURNO", $turno);
$control->bindParam("SEMANA", $semana);
$control->execute();

header('Location: http://localhost/Projeto/visualizacao/home.php');
}else{
    echo "Deu error";
}

?>




