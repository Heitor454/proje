<?php
// conexão com o banco de dados;

require_once('conexao.php');

if(isset($_POST['txtArea'])
&& isset($_POST['txtCurso'])
&& isset($_POST['txtProfessores']) 
){

 //captura os dados vindos do input do formulário;
$area['txtArea'];
$curso['txtCurso'];
$professores['txtProfessores'];

//insere os dados no banco de dados;

$control = $conecta->prepare("INSERT INTO tb_departamento(area, curso, professores) 
VALUES (:, :, :, )");
$control->bindParam("AREA", $Area);
$control->bindParam("CURSO", $Curso);
$control->bindParam("PROFESSORES", $professores);
$control->execute();

header('Location: http://localhost/Projeto/visualizacao/home.php');
}else{
    echo "Deu error";
}

?>




