<?php
// conexão com o banco de dados;

require_once('conexao.php');

if(isset($_POST['txtDisciplina'])
&& isset($_POST['txtNota'])
&& isset($_POST['txtFaltas']) 
&& isset($_POST['txtC.H']) 
&& isset($_POST['txtDependencia']) 
&& isset($_POST['txtAcao']) 
){

 //captura os dados vindos do input do formulário;
$disciplina['txtDisciplina'];
$curso['txtNota'];
$professores['txtFaltas'];
$CH['txtC.H'];
$dependencia['txtDependencia'];
$acao['Acao'];
//insere os dados no banco de dados;

$control = $conecta->prepare("INSERT INTO tb_departamento(disciplina,curso,professores,CH,dependencia,acao ) 
VALUES (:DISCIPLINA, :CURSO, :PROFESSORES, :CH, :DEPENDENCIA, :ACAO, )");
$control->bindParam("AREA", $Area);
$control->bindParam("CURSO", $Curso);
$control->bindParam("PROFESSORES", $professores);
$control->execute();

header('Location: http://localhost/Projeto/visualizacao/home.php');
}else{
    echo "Deu error";
}

?>
