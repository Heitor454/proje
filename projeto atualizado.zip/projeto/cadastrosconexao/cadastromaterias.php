<?php
// conexão com o banco de dados;

require_once('conexao.php');

if(isset($_POST['txtPortugues'])
&& isset($_POST['txtMatematica'])
&& isset($_POST['txtHistoria']) 
&& isset($_POST['txtGeografia']) 
&& isset($_POST['txtFisica']) 
&& isset($_POST['txtQuimica']) 
&& isset($_POST['txtBiologia']) 
&& isset($_POST['txtFilosofia']) 
){

 //captura os dados vindos do input do formulário;
$portugues['txtPortugues'];
$matematica['txtMatematica'];
$historia['txtHistoria'];
$geografia['txtGeografia'];
$fisica['txtFisica'];
$quimica['txtQuimica'];
$biologia['txtBiologia'];
$filosofia['txtFilosofia'];



//insere os dados no banco de dados;

$control = $conecta->prepare("INSERT INTO tb_materias(portugues,matematica,historia,geografia,fisica,quimica,biologia,filosofia) 
VALUES (:PORTUGUES, :MATEMATICA, 
:HISTORIA, :GEOGRAFIA, :FISICA, :QUIMICA, :BIOLOGIA, :FILOSOFIA, )");
$control->bindParam("PORTUGUES", $portugues);
$control->bindParam("MATEMATICA", $matematica);
$control->bindParam("HISTORIA", $historia);
$control->bindParam("GEOGRAFIA", $geografia);
$control->bindParam("FISICA", $fisica);
$control->bindParam("QUIMICA", $quimica);
$control->bindParam("BIOLOGIA", $biologia);
$control->bindParam("FILOSOFIA", $filosofia);
$control->execute();

header('Location: http://localhost/Projeto/visualizacao/home.php');
}else{
    echo "Deu error";
}

?>
