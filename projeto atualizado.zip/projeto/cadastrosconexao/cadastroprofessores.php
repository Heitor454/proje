<?php
// conexão com o banco de dados;

require_once('conexao.php');

if(isset($_POST['txtCadastro_dos_professores'])
&& isset($_POST['txtNome_dos_professores'])
&& isset($_POST['txtNome_completo'])
&& isset($_POST['txtNome_abreviado']) 
&& isset($_POST['txtMorada']) 
&& isset($_POST['txtCP']) 
&& isset($_POST['txtLocalidade']) 
&& isset($_POST['txtTelefone']) 
&& isset($_POST['txtFax']) 
&& isset($_POST['txtTelemovel']) 
&& isset($_POST['txtEmail']) 
&& isset($_POST['txtData_de_nascimento']) 
&& isset($_POST['txtNº_bi']) 
&& isset($_POST['txtArq_ident']) 
&& isset($_POST['txtHabilitacoes_literarias']) 
&& isset($_POST['txtProfissao']) 
&& isset($_POST['txtArea_de_actividade']) 
&& isset($_POST['txtMorada_do_trabalho/escola']) 
&& isset($_POST['txtFormado_pelo_ccpfc']) 
&& isset($_POST['txtData_de_inicio_de_actividade']) 
&& isset($_POST['txtArea_dominante']) 
){

 //captura os dados vindos do input do formulário;
$cadastro_dos_professores['txtCadastro_dos_professores'];
$nome_completo['txtNome_completo'];
$nome_abreviado['txtNome_abreviado'];
$cp['txtCp'];
$localidade['txtLocalidade'];
$telefone['txtTelefone'];
$fax['txtFax'];
$telemovel['txtTelemovel'];
$email['txtEmail'];
$data_de_nascimento['txtData_de_nascimento'];
$nº_bi['txtNº_bi'];
$arq_ident['txtArq_ident'];
$habitacoes_literarias['txtHabilitacoes_literarias'];
$profissao['txtProfissao'];
$area_de_actividade['txtArea_de_actividade'];
$morada['txtMorada'];
$formado_pelo_ccpfc['txtFormado_pelo_ccpfc'];
$data_de_inicio_de_actividade['txtData_de_inicio_de_actividade'];
$area_dominante['txtArea_dominante'];


//insere os dados no banco de dados;

$control = $conecta->prepare("INSERT INTO tb_cadastroprofessores(cadastro_dos_professores, nome_completo, nome_abreviado, cp, 
localidade, telefone, fax, telemovel, email, data_de_nascimento, nº_bi, arq_ident, habitacoes, profissao, area_de_actividade, morada,
formado_pelo_ccpfc, data_de_inicio_de_actividade, area_domininta,)

VALUES (:CADASTRO_DOS_PROFESSORES, :NOME_COMPLETO, :NOME_ABREVIADO, :CP, :LOCALIDADE, :TELEFONE, :FAX, :TELEMOVEL, :EMAIL, :DATA_DE_NASCIMENTO, :Nº_BI, 
:ARQ_IDENT, :HABITACOES_LITERARIAS, :PROFISSAO, :AREA_DE_ACTIVIDADE, :MORADA, :FORMADO_PELO_CCPFC, :DATA_DE_INICIO_DE_ACTIVDADE, :AREA_DOMINANTE, )");
$control->bindParam("CADASTRO_DOS_PROFESSORES", $cadastro_dos_professores);
$control->bindParam("NOME_COMPLETO", $nome_completo);
$control->bindParam("NOME_ABREVIADO", $nome_abreviado);
$control->bindParam("CP", $cp);
$control->bindParam("LOCALIDADE", $localidade);
$control->bindParam("TELEFONE", $telefone);
$control->bindParam("FAX", $fax);
$control->bindParam("TELEMOVEL", $telemovel);
$control->bindParam("EMAIL", $email);
$control->bindParam("DATA_DE_NASCIMENTO", $data_de_nascimento);
$control->bindParam("Nº_BI", $nº_bi);
$control->bindParam("ARQ_IDENT", $arq_ident);
$control->bindParam("HABITACOES_LITERARIAS", $habitacoes_literarias);
$control->bindParam("PROFISSAO", $profissao);
$control->bindParam("AREA_DE_ACTIVIDADE", $area_de_actividade);
$control->bindParam("MORADA", $morada);
$control->bindParam("FORMADO_PELO_CCPFC", $formado_pelo_ccpfc);
$control->bindParam("DATA_DE_INICIO_DE_ACTIVDADE", $data_de_inicio_de_actividade);
$control->bindParam("AREA_DOMINANTE", $area_dominante);

$control->execute();

header('Location: http://localhost/Projeto/visualizacao/home.php');
}else{
    echo "Deu error";
}

?>
