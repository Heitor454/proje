<?php
// conexão com o banco de dados;

require_once('conexao.php');

if (
    isset($_POST['txtEscola'])
    && isset($_POST['txtProfessores'])
    && isset($_POST['txtTurma'])
    && isset($_POST['txtNome_dos_alunos'])
    && isset($_POST['txtUnidade_de_ensino'])
    && isset($_POST['txtModalidade'])
    && isset($_POST['txtFechamentos_das_turmas'])
    && isset($_POST['txtEstrutura_curricular'])
    && isset($_POST['txtClassificacoes_das_turmas'])
    && isset($_POST['txtSerie'])
    && isset($_POST['txtTipo_de_aprovacao'])
    && isset($_POST['txtQuantidade_de_turmas'])
    && isset($_POST['txtQuantidade_de_alunos'])
    && isset($_POST['txtCadastro_de_turmas'])
    && isset($_POST['txtNomeclatura_de_turmas'])
    && isset($_POST['txtPeriodo_letivo'])
) {
    //captura os dados vindos do input do formulário;
    $escola['txt'];
    $professores['txt'];
    $turma['txtProfessores'];
    $nome_dos_alunos['txtProfessores'];
    $unidade_de_ensino['txtProfessores'];
    $modalidade['txtProfessores'];
    $fechamento_da_turma['txtProfessores'];
    $estrutura_curricular['txtProfessores'];
    $classificacoes_das_turmas['txtProfessores'];
    $serie['txtProfessores'];
    $tipo_de_aprovacao['txtProfessores'];
    $quantidade_de_turmas['txtProfessores'];
    $quantidade_de_alunos['txtProfessores'];
    $cadastro_de_turmas['txtProfessores'];
    $nomeclatura_de_turmas['txtProfessores'];
    $periodo_letivo['txtProfessores'];


    //insere os dados no banco de dados;

    $control = $conecta->prepare("INSERT INTO tb_departamento
(escola, 
professores, 
turma, 
nome_dos_alunos, 
unidade_de_ensino, 
modalidade, 
fechamento_da_turma, 
estrutura_curricular, 
classificacoes_das_turmas, 
serie, tipo_de_aprovacao, 
quatidade_de_turmas, 
quantidade_de_alunos, 
cadastro_de_turmas, 
nomeclatura_de_turmas, 
periodo_letivo,) 

VALUES (:ESCOLA, 
:PROFESSORES, 
:TURMA, 
:NOME_DOS_ALUNOS, 
:UNIDADE_DE_ENSINO, 
:MODALIDADE, 
:FECHAMENTO_DAS_TURMAS, 
:ESTRUTURA_CURRICULAR, 
:CLASSIFICACOES_DAS_TURMAS, 
:SERIE, 
:TIPO_DE_APROVACAO, 
:QUANTIDADES_DE_TURMAS, 
:QUANTIDADES_DE_ALUNOS, 
:CADASTRO_DE_TURMAS, 
:NOMECLATURA_DE_TURMAS, 
:PERIODO_LETIVO, )");

    $control->bindParam("ESCOLA", $escola);
    $control->bindParam("PROFESSOR", $Professor);
    $control->bindParam("TURMA", $turma);
    $control->bindParam("NOME_DOS_ALUNOS", $nome_dos_alunos);
    $control->bindParam("UNIDADE_DE_ENSINO", $unidade_de_ensino);
    $control->bindParam("MODALIDADE", $modalidade);
    $control->bindParam("FECHAMENTO_DAS_TURMAS", $fechamento_da_turma);
    $control->bindparam("ESTRUTURA_CURRICULAR",$estrutura_curricular);
    $control->bindParam("CLASSIFICACOES_DAS_TURMAS", $classificacoes_das_turmas);
    $control->bindParam("SERIE", $serie);
    $control->bindParam("TIPO_DE_APROVACAO", $tipo_de_aprovacao);
    $control->bindParam("QUANTIDADES_DE_TURMAS", $quantidade_de_turmas);
    $control->bindParam("QUANTIDADES_DE_ALUNOS", $quantidade_de_alunos);
    $control->bindParam("CADASTRO_DE_TURMAS", $cadastro_de_turmas);
    $control->bindParam("NOMECLATURA_DE_TURMAS", $nomeclatura_de_turmas);
    $control->bindParam("PERIODO_LETIVO", $periodo_letivo);
    $control->execute();

    header('Location: http://localhost/Projeto/visualizacao/home.php');
} else {
    echo "funcionou";
}
