<!-- conexão com o banco de dados; -->
<?php
$conecta = new PDO("mysql:dbname=db_tuxbook;host=localhost", "root", "");
?>