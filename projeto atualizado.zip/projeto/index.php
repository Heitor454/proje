<!DOCTYPE html>
<html lang="pt-br">

<h1>Cadastrar Aluno</h1>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="css/style.css" />


    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <title>Logar</title>
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
        <div class="container">
            <a href="#">
                <img src="img/logo/logo.png" alt="" class="img-fluid rounded">
            </a>
            <div class="row d-flex">
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Alunos</button>
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Cursos</button>
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Matérias</button>
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Histórico de Alunos</button>
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Professores</button>
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Turma</button>
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Departamento</button>
                <button class="btn btn-dark" data-toggle="modal" data-target="#modalExemplo">Administrador</button>
            </div>
        </div>
    </nav>
    <section class="bg-secondary mt-5">
        <div class="container bg-secondary mt-5">
            <div class="row mt-5">
               
            </div>
        </div>
    </section>

    <!--Corpo-->
    <div class="corpo container">

    </div>

    <!-- Modal -->
    <div class="modal fade align-self-center" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content  bg-light ">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Entrar</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                        
                    </button>
                </div>
                <div class="modal-body bg-light">
                    <form>
                        <div class="form-group">
                            <input class="form-control" type="email" placeholder="exemplo@mail.com" required>
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="password" placeholder="Informe a senha" required>
                        </div>
                        <div class="modal-footer">
                            <button click="button_cadastrar" type="button" class="btn btn-sm btn-secondary " data-dismiss="modal">Logar</button>
                        </div>
  
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>

<aside>
    <h3>Barra lateral</h3>
    <p>Na década de 1960, o Instituto de Tecnologia de Massachusetts era um dos principais centros de pesquisa na área da computação no mundo e dispunha do TX-0, 
       um computador dotado de transistores, ao invés de válvulas, 
       e que era menor que os mainframes padrão da época. </p>
    <ul>
        <li><a href="/alunos.php">Alunos</a></li>
        <li><a href="/cursos.php">Cursos</a></li>
        <li><a href="/materias.php">Matérias</a></li>
        <li><a href="/historicodealunos.php">Histórico de alunos</a></li>
        <li><a href="/professores.php">Professores</a></li>
        <li><a href="/turmas.php">Turmas</a></li>
        <li><a href="/departamento.php">Departamento</a></li>
        <li><a href="/administrador.php">Administrador</a></li>
    </ul>
</aside>


