create database alunos;
use alunos;

/* ----------------------
 |    Tabela de administrador |
 ------------------------*/
create table tb_administrador(
	idadministrador int primary key auto_increment,
    nome varchar(200) not null,
    cpf int not null unique,
    email varchar(145) not null,
    senha init,
	Matruicula varchar(145) not null,
    foreign key(alunos_id) references tb_alunos(idaluno),
    foreign key(professores_id) references tb_professores(idprofessor),
 
);

 /* ----------------------
 |    Tabela de alunos  |
 ------------------------*/
create table tb_alunos(
	idalunos int primary key auto_increment,
    nome varchar(200) not null,
    sobrenome varchar(200) not null,
    cpf varchar(15) not null unique,
    rg varchar(15) not null unique,
    cursoPrestado varchar(145) not null,
    professor init,
	Matruicula varchar(145) not null,
    sexo enum("M", "F") not null,
    turma init,
    historico init,
    email varchar(255) not null,
    foreign key(aluno_id) references tb_alunos(idaluno),
    foreign key(professor_id) references tb_professores(idprofessor),
    foreign key(curso_id) references tb_cursos(idcurso),
    foreign key(turma_id) references tb_turmas(idturma),
    foreign key(histórico_id) references tb_histórico(idhistórico)
);

 /* ----------------------
 |    Tabela de cursos |
 ------------------------*/
create table tb_cursos(
	idcursos int primary key auto_increment,
    aluno init,
    nome varchar(100) not null,
    datadenascimento varchar(10) not null,
    endereco varchar(65) not null,
    cep varchar(8) not null,
    cidade varchar(20) not null,
    telefone varchar(13) not null,
    celular varchar(13) not null,
    email varchar(80) not null,
    interesse int,
    turno init,
    semana init,
	turma init,
    cadastrocursos varchar(200) not null,
    cursos_id int not null,
    foreign key(aluno_id) references tb_alunos(idaluno),
    foreign key(turno_id) references tb_turnos(idturnos),
    foreign key(semana_id) references tb_semanas(idsemanas),
    foreign key(turma_id) references tb_turmas(idturmas),
);

 /* ----------------------
 |    Tabela de matéria |
 ------------------------*/
 create table tb_materia(
	idmaterias int primary key auto_increment,
    português varchar(45),
    Matemática varchar (45),
    História varchar(45),
    Geografia varchar (45),
    Física varchar (45),
    Química varchar (45),
    Biologia varchar (45),
    Filosofia varchar(45),
    matérias_id int not null,
    foreign key(aluno_id) references tb_alunos(idaluno),
    foreign key(turno_id) references tb_turnos(idturnos),
    foreign key(semana_id) references tb_semanas(idsemanas),
    foreign key(turma_id) references tb_turmas(idturmas),
);
 /* ----------------------
 |    Tabela de historico  |
 ------------------------*/
create table tb_historico(
	idhistorico int primary key auto_increment,
    diciplinas varchar(13) not null,
    nota varchar(10) not null,
    faltas(15) not null,
    C.H varchar(45) not null,
    dependencia(15) not null,
    acao varchar(15) not null,
	historico_id int not null
    foreign key(aluno_id) references tb_alunos(idaluno)
);

 /* ----------------------
 |    Tabela de professores |
 ------------------------*/
create table tb_professores(
	idprofessores int primary key auto_increment,
    Cadastro_dos_professores varchar(150) not null,
    Nome_Completo varchar(150) not null,
    Nome_Abreviado varchar(150) not null,
    Morada varchar(150) not null,
    C.P varchar(150) not null,
    Localidade varchar(150) not null,
    Telefone varchar(150) not null,
    Fax varchar(150) not null,
    Telemovel varchar(150) not null,
    Email varchar(150) not null,
    Data_de_Nascimento varchar(150) not null,
    Nº BI varchar(150) not null,
    Arq_Ident varchar(150) not null,
    Habitações varchar(150) not null,
    Profissão varchar(150) not null,
    Área_de_Actividade varchar(150) not null,
    Morada_do_Trabalho varchar(150) not null,
    Formado(a)_pelo_CCPFC varchar(150) not null,
    Data_de_Início varchar(150) not null,
    Área_Dominante varchar(150) not null,
	professores_id int not null
);

 /* ----------------------
 |    Tabela de turmas  |
 ------------------------*/
create table tb_cadastro_de_turmas(
	idcadastroturma int primary key auto_increment,
    Escola varchar(45) not null,
    Processor(a) varchar(145) not null,
    Turma varchar(145) not null,
    Nome_dos_Alunos varchar(145) not null,
    Unidade_de_Ensino varchar(145) not null,
    Modalidade varchar(145) not null,
    Fechamento_das_Turmas varchar(145) not null,
    Estrutura_Curricular varchar(145) not null,
    Classificações_das_Turmas varchar(145) not null,
    Série varchar(145) not null,
    Tipo_de_Aprovação varchar(145) not null,
    Quantidades_de_Turmas varchar(145) not null,
    Quantidades_de_Alunos varchar(145) not null,
    Cadastro_de_Turmas varchar(145) not null,
    Nomeclatura_de_Turmas varchar(145) not null,
    Período_Letivo varchar(145) not null,
);

 /* ----------------------
 |    Tabela de departamento  |
 ------------------------*/
create table tb_departamento(
	iddepartamento int primary key auto_increment,
    Área varchar(145) not null,
    Professor(a) varchar(45) not null unique,
    Departamento varchar(255) not null,
     foreign key(aluno_id) references tb_alunos(idaluno)
);
-- Inserção de dados do usuario
insert into tb_alunos values (null, 'Administrador do Sistema', 'admin', 'senac@2121');

select idaluno, nome, login from tb_usuarios where login = 'admin' and senha = 'senac@2121';

-- Encriptografia usando MD5
-- atualizar um ou campos da tabela
update tb_alunos set senha = md5("senac@2121") where login = "admin";

-- Views (amostragens)
create view vw_alunos as
select 
	tb_alunos.idcandidato, 
	tb_alunos.nome, 
	tb_.alunos.sobrenome, 
    tb_alunos.cpf, 
    tb_alunos.rg, 
    tb_alunos.cursoPrestado, 
    tb_alunos.sexo, 
    tb_alunos.email, 
    tb_alunos.nota, 
    tb_cursos.numero,
    tb_areas_de_interesses.area_interesse,
    tb_enderecos.logradouro,
    tb_enderecos.bairro,
    tb_enderecos.cidade
from tb_alunos
inner join tb_telefones
on tb_candidatos.idcandidato = tb_telefones.candidato_id
inner join tb_areas_de_interesses
on tb_areas_de_interesses.candidato_id = tb_candidatos.idcandidato
inner join tb_enderecos
on tb_enderecos.candidato_id = tb_candidatos.idcandidato;