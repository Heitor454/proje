<?php
//Chama o cabeçalho;
require_once('../component/header.php');

//Chama a conexão com o banco de dados;
require_once('../DB/conexao.php');

//Lendo dados do banco de dados;

$control = $conecta->prepare("SELECT * FROM tb_livro ORDER BY titulo asc");
$control->execute();

//Pega toda a tabela e guarda em uma variável;
$resultado = $control->fetchALL(PDO::FETCH_ASSOC);
?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous">
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Professores</title>
</head>

<body>
    <section class="container mt-3">
        <div class="row text-center">
            <?php
            foreach ($resultado as $rows) {
             echo ("
             <div class = 'col-3'>

             <div class = 'card mt-3 mb-3 mr-3' style = 'widith: 15rem; font-size: 13px; box-shadow: 0 0 1em; '>

                 <div class = 'card-header' style = 'font-size: 16px;'>

                     ".$rows['Professores']."

                 </div>

                 <div class = 'card-body'>

                     <p class = 'card-text'> <strong> Cadastro_dos_professores: </strong>".$rows['isbn']." </p>
                     <p class = 'card-text'> <strong> Nome_completo: </strong>".$rows['nome_completo']." </p>
                     <p class = 'card-text'> <strong> Nome_abreviado: </strong>".$rows['nome_abreviado']." </p>
                     <p class = 'card-text'> <strong> Morada: </strong>".$rows['morada']." </p>
                     <p class = 'card-text'> <strong> C.p: </strong>".$rows['c.p']." </p>
                     <p class = 'card-text'> <strong> Cadastro_dos_professores: </strong>".$rows['cadastro_dos_professores']." </p>
                     <p class = 'card-text'> <strong> Localidade: </strong>".$rows['localidade']." </p>
                     <p class = 'card-text'> <strong> Telemovel: </strong>".$rows['telemovel']." </p>
                     <p class = 'card-text'> <strong> Email: </strong>".$rows['email']." </p>
                     <p class = 'card-text'> <strong> Data_de_nascimento: </strong>".$rows['data_de_nascimento']." </p>
                     <p class = 'card-text'> <strong> Nº_bi: </strong>".$rows['nº_init']." </p>
                     <p class = 'card-text'> <strong> Arq_ident: </strong>".$rows['arq_ident']." </p>
                     <p class = 'card-text'> <strong> Habitacoes: </strong>".$rows['habitacoes']." </p>
                     <p class = 'card-text'> <strong> Profissao: </strong>".$rows['profissao']." </p>
                     <p class = 'card-text'> <strong> Area_de_actividade: </strong>".$rows['area_de_actividade']." </p>
                     <p class = 'card-text'> <strong> Morada_do_trabalho: </strong>".$rows['morada_do_trabalho']." </p>
                     <p class = 'card-text'> <strong> Formado_pelo_ccpfc: </strong>".$rows['formado_pelo_ccpfcisbn']." </p>
                     <p class = 'card-text'> <strong> Data_de_inicio: </strong>".$rows['data_de_inicio']." </p>
                     <p class = 'card-text'> <strong> Area_dominante: </strong>".$rows['area_dominante']." </p>

                     <a href='#' class='btn btn-success'> Ver </a>
                     <a href ='../exclusao/deleteprofessor.php?id=". $rows['id'] . "' class='btn btn-danger'> Deletar</a>

                 </div>

             </div>                            

         </div>      


             
             ");
            }

            ?>
        </div>
    </section>
</body>

</html>