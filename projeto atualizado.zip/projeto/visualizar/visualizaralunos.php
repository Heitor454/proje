<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <link rel="shortcut icon" type="imagex/png" href="../img/logo/logo.png">


    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alunos</title>
</head>

<body class="bg-light">
    <!-- Cabeçaho -->
    <?php
    require_once('../component/header.php');    ?>


    <section class="container justify-content-center">
        <div class="wrapper bg-light mt-5 ">
            <h2 class="mb-3 mt-3 text-center">Cadastro de Alunos</h2>
            <form action="../cadastrosconexao/cadastroalunos.php" method="POST">
                <div class="form-row">
                    <div class="col form-group">
                        <label for="id_nome">Nome:</label>
                        <input type="text" placeholder="Informe o Nome" name="txtNomr" class="form-control" id="id_nome">
                    </div>
                    <div class="col">
                        <label for="id_email"> Email:</label>
                        <input class="form-control" type="email" placeholder="senac@gmail.com" name="txtEmail" id="id_email">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col">
                        <label for="id_cpf">Cpf:</label>
                        <input class="form-control" type="text" placeholder="mail@mail.com" name="txtMail" id="id_mail">
                    </div>
                    <div class="col">
                        <label for="id_telefone">Telefone:</label>
                        <input class="form-control" type="telefone" placeholder="(21) 99999-9999)" name="txtTel" id="id_tel">
                    </div>
                    <div class="col">
                        <label for="id_data_de_nascimento">Data De Nascimento:</label>
                        <input class="form-control" type="text" placeholder="21/06/2000" name="txtData_de_nascimento" id="id_data_de_nascimento">
                    </div>
                    <div class="col">
                        <label for="id_celular">Celular:</label>
                        <input class="form-control" type="celular" placeholder="(21) 99999-9999)" name="txt" id="id_celular">
                    </div>
                    <div class="col">
                        <label for="id_genero">Gênero:</label>
                        <input class="form-control" type="text" placeholder="Informe o gênero" name="txtGenero" id="id_genero">
                    </div>
                    <div class="col">
                        <label for="id_forma_de_ingressso">Forma de Ingresso:</label>
                        <input class="form-control" type="text" placeholder="Escokha a forma de ingresso" name="txtForma_de_ingresso" id="id_forma_de_ingresso">
                    </div>
                    <div class="col">
                        <label for="id_curso">Curso:</label>
                        <input class="form-control" type="text" placeholder="Informe o curso" name="txtTel" id="id_curso">
                    </div>
                    <div class="col">
                        <label for="id_habilitacao">Habilitação:</label>
                        <input class="form-control" type="text" placeholder="Habilitado para a prova" name="txtHabilitacao" id="id_habilitacao">
                    </div>
                    <div class="col">
                        <label for="id_desconto">Desconto:</label>
                        <input class="form-control" type="text" placeholder="Desconto para adicionar" name="txtDesconto" id="id_desconto">
                    </div>
                    <div class="col">
                        <label for="id_data_da_prova">Data da Prova:</label>
                        <input class="form-control" type="text" placeholder="Coloque a data da prova." name="txtTel" id="id_">
                    </div>
                    <div class="col">
                        <label for="id_horario_da_prova">Horario da Prova:</label>
                        <input class="form-control" type="text" placeholder="Coloque a hora que será feita a prova" name="txtHorario_da_prova" id="id_horario_da_prova">
                    </div>
                    <div class="col">
                        <label for="id_local_da_prova">Local da Prova:</label>
                        <input class="form-control" type="text" placeholder="Coloque o local da prova" name="txtLocal_da_prova" id="id_">
                    </div>
                    <div class="col">
                        <label for="id_cpf">Cpf:</label>
                        <input class="form-control" type="text" placeholder="Coloque seu cpf" name="txtCpf" id="id_cpf">
                    </div>
                    <div class="col">
                        <label for="id_rg">Rg:</label>
                        <input class="form-control" type="text" placeholder="Coloque seu registro geral" name="txtRg" id="id_rg">
                    </div>
                    <div class="col">
                        <label for="id_cep">Cep:</label>
                        <input class="form-control" type="text" placeholder="Preencha este espaço" name="txtCep" id="id_cep">
                    </div>
                    <div class="col">
                        <label for="id_endereco">Endereço:</label>
                        <input class="form-control" type="tel" placeholder="" name="txtTel" id="id_">
                    </div>
                    <div class="col">
                        <label for="id_n">N:</label>
                        <input class="form-control" type="text" placeholder="Coloque seu número aqui." name="txtN" id="id_n">
                    </div>
                    <div class="col">
                        <label for="id_complemento">Complemento:</label>
                        <input class="form-control" type="tel" placeholder="" name="txtComplemento" id="id_complemento">
                    </div>
                    <div class="col">
                        <label for="id_bairro">Bairro:</label>
                        <input class="form-control" type="tel" placeholder="" name="txtTel" id="id_">
                    </div>
                    <div class="col">
                        <label for="id_cidade">Cidade:</label>
                        <input class="form-control" type="text" placeholder="Coloque sua cidade aqui." name="txt" id="id_cidade">
                    </div>
                    <div class="col">
                        <label for="id_nome_social">Nome Social:</label>
                        <input class="form-control" type="text" placeholder="Caso tenha, coloque." name="txtNome_social" id="id_nome_social">
                    </div>
                    <div class="col">
                        <label for="id_necessidade_especial">Necessidade especial:</label>
                        <input class="form-control" type="text" placeholder="Caso seja, preencha." name="txtNecessidade_especial" id="id_necessidade_especial">
                    </div>


                </div>
                <div class="form-row mt-3">
                    <div class="col text-center">
                        <button class="btn btn-secondary ">Cadastrar</button>
                    </div>
                </div>
            </form>
        </div>
        </div>
    </section>

</body>

</html>