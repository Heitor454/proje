<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <link rel="shortcut icon" type="imagex/png" href="../img/logo/logo.png">


    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cursos</title>
</head>

<body class="bg-light">
    <!-- Cabeçaho -->
    <?php
    require_once('../component/header.php');    ?>


    <section class="container justify-content-center">
        <div class="wrapper bg-light mt-5 ">
            <h2 class="mb-3 mt-3 text-center">Cadastro de Cursos</h2>
            <form action="../cadastrosconexao/cadastrocursos.php" method="POST">
                <div class="form-row">
                    <div class="col form-group">
                        <label for="id_nome">Nome:</label>
                        <input type="text" placeholder="Informe o Nome" name="txtName" class="form-control" id="id_nome">
                    </div>
                    <div class="col">
                        <label for="id_cpf"> Data de Nascimento:</label>
                        <input class="form-control" type="text" placeholder="21/09/1998" name="txtData_de_nascimento" id="id_data_de_nascimento">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col">
                        <label for="id_endereco"></label>Endereço:</label>
                        <input class="form-control" type="text" placeholder="Informe seu endereço" name="txtEndereco" id="id_endereco">
                    </div>

                    <div class="col">
                        <label for="id_cep">Cep:</label>
                        <input class="form-control" type="text" placeholder="Informe seru cep" name="txtCep" id="id_cep">
                    </div>

                    <div class="col">
                        <label for="id_cidade">Cidade:</label>
                        <input class="form-control" type="text" placeholder="Informa sua cidade" name="txtCidade" id="id_cidade">
                    </div>
                    <div class="col">
                        <label for="id_telefone">Telefone:</label>
                        <input class="form-control" type="text" placeholder="Informe seu número" name="txtTelefone" id="id_telefone">
                    </div>
                    <div class="col">
                        <label for="id_celular">Celular:</label>
                        <input class="form-control" type="text" placeholder="Informe seu número" name="txtCelular" id="id_celular">
                    </div>
                    <div class="col">
                        <label for="id_email">Email:</label>
                        <input class="form-control" type="text" placeholder="Informe o email" name="txtEmail" id="id_email">
                    </div>
                    <div class="col">
                        <label for="id_interesse">Interesse:</label>
                        <input class="form-control" type="text" placeholder="Interesse em qual matéria" name="txtInteresse" id="id_interesse">
                    </div>
                    <div class="col">
                        <label for="id_turno">Turno:</label>
                        <input class="form-control" type="text" placeholder="Informe qual turno escolher" name="txtTurno" id="id_turno">
                    </div>
                    <div class="col">
                        <label for="id_semana">Semana:</label>
                        <input class="form-control" type="text" placeholder="Qual semana vai escolher" name="txtSemana" id="id_semana">
                    </div>


                </div>
                <div class="form-row mt-3">
                    <div class="col text-center">
                        <button class="btn btn-secondary ">Cadastrar</button>
                    </div>
                </div>
            </form>
        </div>
        </div>
    </section>

</body>

</html>