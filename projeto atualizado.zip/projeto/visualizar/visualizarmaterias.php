<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <link rel="shortcut icon" type="imagex/png" href="../img/logo/logo.png">


    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Matérias</title>
</head>

<body class="bg-light">
    <!-- Cabeçaho -->
    <?php
    require_once('../component/header.php');    ?>


    <section class="container justify-content-center">
        <div class="wrapper bg-light mt-5 ">
            <h2 class="mb-3 mt-3 text-center">Cadastro de Matérias</h2>
            <form action="../cadastrosconexao/cadastromaterias.php" method="POST">
                <div class="form-row">
                    <div class="col form-group">
                        <label for="id_portugues">Português:</label>
                        <input type="text" placeholder="Informe a matéria" name="txtName" class="form-control" id="id_portugues">
                    </div>
                    <div class="col">
                        <label for="id_matematica"> Matemática:</label>
                        <input class="form-control" type="text" placeholder="Informe a matéria" name="txtCPF" id="id_matematica">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col">
                        <label for="id_historia">História:</label>
                        <input class="form-control" type="text" placeholder="Informe a matéria" name="txtMail" id="id_historia">
                    </div>
                    <div class="col">
                        <label for="id_geografia">Geografia:</label>
                        <input class="form-control" type="text" placeholder="Informe a matéria" name="txt" id="id_geografia">
                    </div>
                    <div class="col">
                        <label for="id_fisica"> Física:</label>
                        <input class="form-control" type="text" placeholder="Informe a matéria" name="txtCPF" id="id_fisica">
                    </div>
                    <div class="col">
                        <label for="id_quimica"> Química:</label>
                        <input class="form-control" type="text" placeholder="Informe a matéria" name="txtCPF" id="id_quimica">
                    </div>
                    <div class="col">
                        <label for="id_biologia"> Biologia:</label>
                        <input class="form-control" type="text" placeholder="Informe a matéria" name="txtCPF" id="id_biologia">
                    </div>
                    <div class="col">
                        <label for="id_filosofia"> Filosofía:</label>
                        <input class="form-control" type="text" placeholder="Informe a matéria" name="txtCPF" id="id_filosofia">
                    </div>
                </div>
                <div class="form-row mt-3">
                    <div class="col text-center">
                        <button class="btn btn-secondary ">Cadastrar</button>
                    </div>
                </div>
            </form>
        </div>
        </div>
    </section>

</body>

</html>