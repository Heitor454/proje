<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <link rel="shortcut icon" type="imagex/png" href="../img/logo/logo.png">


    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Professores</title>
</head>

<body class="bg-light">
    <!-- Cabeçaho -->
    <?php
    require_once('../component/header.php');    ?>


    <section class="container justify-content-center">
        <div class="wrapper bg-light mt-5 ">
            <h2 class="mb-3 mt-3 text-center">Cadastro de professores</h2>
            <form action="../cadastrosconexao/cadastroprofessores.php" method="POST">

                <div class="form-row">
                    <div class="col form-group">
                        <label for="id_cadastro_dos_professores">Cadastro dos professores:</label>
                        <input type="text" placeholder="Informe quais são os professores" name="txtCadastro_dos_professores" class="form-control" id="id_cadastro_dos_professores">
                    </div>
                    <div class="col">
                        <label for="id_nome_completo"> Nome completo:</label>
                        <input class="form-control" type="text" placeholder="Informe seu nome todo." name="txtCPF" id="id_nome_completo">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col">
                        <label for="id_nome_abreviado">Nome abreviado:</label>
                        <input class="form-control" type="text" placeholder="" name="txtNome_abreviado." id="id_nome_abreviado">
                    </div>
                    <div class="col">
                        <label for="id_morada">Morada:</label>
                        <input class="form-control" type="tel" placeholder="Onde mora?" name="txtTel" id="id_morada">
                    </div>
                    <div class="col">
                        <label for="id_c.p">C.P:</label>
                        <input class="form-control" type="tel" placeholder="Informa a coordenação pedagógica." name="txtC.p" id="id_c.p">
                    </div>
                    <div class="col">
                        <label for="id_localidade">localidade:</label>
                        <input class="form-control" type="text" placeholder="Informa sua localidade." name="txtLocalidade" id="id_localidade">
                    </div>
                    <div class="col">
                        <label for="id_telefone">Telefone:</label>
                        <input class="form-control" type="tel" placeholder="(21)8787-8984" name="txtTelefone" id="id_telefone">
                    </div>
                    <div class="col">
                        <label for="id_fax">Fax:</label>
                        <input class="form-control" type="tel" placeholder="(21)8787-8989" name="txtFax" id="id_fax">
                    </div>
                    <div class="col">
                        <label for="id_telemovel">Telemovel:</label>
                        <input class="form-control" type="tel" placeholder="Informa a coordenação pedagógica." name="txtTelemovel" id="id_telemovel">
                    </div>
                    <div class="col">
                        <label for="id_email">Email:</label>
                        <input class="form-control" type="text" placeholder="Informa seu email." name="txtEmail" id="id_email">
                    </div>
                    <div class="col">
                        <label for="id_data_de_nascimento">Data de nascimento:</label>
                        <input class="form-control" type="text" placeholder="Informa sua data de nascimento." name="txtData_de_nascimento" id="id_data_de_nascimento">
                    </div>
                    <div class="col">
                        <label for="id_nº_bi">Nº Bi:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtNº bi" id="id_nº_bi">
                    </div>
                    <div class="col">
                        <label for="id_Arq init">Arq init:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtArq init" id="id_arq init">
                    </div>
                    <div class="col">
                        <label for="id_habitacoes">Habitações:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtHabitacoes" id="id_habitacoes">
                    </div>
                    <div class="col">
                        <label for="id_profissao">Profissão:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtProfissao" id="id_profissao">
                    </div>
                    <div class="col">
                        <label for="id_area_de_actividade">Area de Actividade:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtArea_de_actividade" id="id_area_de_actividade">
                    </div>
                    <div class="col">
                        <label for="id_morada_do_trabalho/escola">Morada do trabalho/escola:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtMorada _do_trabalho/escola" id="id_morada_do_trabalho">
                    </div>
                    <div class="col">
                        <label for="id_formado(a)_pelo_ccpfc">Formado(a) pelo ccpfc:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtFormado(a)_pelo_ccpfc" id="id_formado(a)_pelo_ccpfc">
                    </div>
                    <div class="col">
                        <label for="id_formado(a)_pelo_ccpfc">Formado(a) pelo ccpfc:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtFormado(a)_pelo_ccpfc" id="id_formado(a)_pelo_ccpfc">
                    </div>
                    <div class="col">
                        <label for="id_data_de_inicio">Data de Início:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtData_de_Inicio" id="id_data_de_inicio">
                    </div>
                    <div class="col">
                        <label for="id_area_dominante">Área dominate:</label>
                        <input class="form-control" type="text" placeholder="Infore aqui." name="txtArea_dominante" id="id_area_dominante">
                    </div>
                </div>
                <div class="form-row mt-3">
                    <div class="col text-center">
                        <button class="btn btn-secondary ">Cadastrar</button>
                    </div>
                </div>
            </form>
        </div>
        </div>
    </section>

</body>

</html>