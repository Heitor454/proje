<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <link rel="shortcut icon" type="imagex/png" href="../img/logo/logo.png">


    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Turmas</title>
</head>

<body class="bg-light">
    <!-- Cabeçaho -->
    <?php
    require_once('../component/header.php');    ?>


    <section class="container justify-content-center">
        <div class="wrapper bg-light mt-5 ">
            <h2 class="mb-3 mt-3 text-center">Cadastro de turmas</h2>
            <form action="../cadastrosconexao/cadastroturmas.php" method="POST">
                <div class="form-row">
                    <div class="col form-group">
                        <label for="id_nome">:</label>
                        <input type="text" placeholder="Informe aqui" name="txtName" class="form-control" id="id_nome">
                    </div>
                    <div class="col">
                        <label for="id_escola"> Escola:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtCPF" id="id_cpf">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col">
                        <label for="id_professor(a)">Professor(a):</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtMail" id="id_mail">
                    </div>
                    <div class="col">
                        <label for="id_turma">:Turma</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtTel" id="id_tel">
                    </div>
                    <div class="col">
                        <label for="id_nome_dos_alunos">:Nome_dos_alunos</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtNome_dos_alunos" id="nome_dos_alunos">
                    </div>
                    <div class="col">
                        <label for="id_unidade_de_ensino">Unidade de ensino:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtUnidade_de_ensino" id="id_unidade_de_ensino">
                    </div>
                    <div class="col">
                        <label for="id_modalidade">Modalidade:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtModalidade" id="id_modalidade">
                    </div>
                    <div class="col">
                        <label for="id_fechamento_das_turmas">Fechamento das turmas:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtFechamento_das_turmas" id="id_fechamento_das_turmas">
                    </div>
                    <div class="col">
                        <label for="id_estrutura_curricular">Estrutura_curricular:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtEstrutura_curricular" id="id_estrutura_curricular">
                    </div>
                    <div class="col">
                        <label for="id_classificacoes_das_turmas">Classificacões das turmas:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtClassificacoes_das_turmas" id="id_classificacoes_das_turmas">
                    </div>
                    <div class="col">
                        <label for="id_serie">Série:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtSerie" id="id_serie">
                    </div>
                    <div class="col">
                        <label for="id_tipo_de_aprovacao">Tipo_de_aprovação:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtTipo_de_aprovacao" id="id_tipo_de_aprovacao">
                    </div>
                    <div class="col">
                        <label for="id_quantidades_de_turmas">Quantidades_de_turmas:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtQuantidades_de_turmas" id="id_quantidades_de_turmas">
                    </div>
                    <div class="col">
                        <label for="id_quantidades_de_alunos">Quantidades de alunos:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtTel" id="id_quantidades_de_alunos">
                    </div>
                    <div class="col">
                        <label for="id_cadastro_de_turmas">Cadastro de turmas:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtCadastro_de_turmas" id="id_cadastro_de_turmas">
                    </div>
                    <div class="col">
                        <label for="id_nomeclatura_de_turmas">Nomeclatura de turmas:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtNomeclatura_de_turmas" id="id_nomeclatura_de_turmas">
                    </div>
                    <div class="col">
                        <label for="id_periodo_letivo">Período_letivo:</label>
                        <input class="form-control" type="text" placeholder="Informe aqui" name="txtPeriodo_letivo" id="id_periodo_letivo">
                    </div>

                </div>
                <div class="form-row mt-3">
                    <div class="col text-center">
                        <button class="btn btn-secondary ">Cadastrar</button>
                    </div>
                </div>
            </form>
        </div>
        </div>
    </section>

</body>

</html>